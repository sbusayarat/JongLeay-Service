**To terminate a WorkSpace**

This example terminates the specified WorkSpace.

Command::

  aws workspaces terminate-workspaces --terminate-workspace-requests wsb-3t36q0xfc

Output::

  {
    "FailedRequests": []
  }